# Triumphant Christian Global Assembly — Triumphant Living Daily Devotional App

Flutter Android application source connected to the existing TCGA Supabase project. This package continues the approved Phase 3 database setup; **do not rerun the database SQL or recreate the Supabase project**.

## Included in this Phase 4 source

- Supabase client initialization from a local `.env` file.
- Today's published devotional and a 120-item devotional archive.
- Scripture text, introduction, teaching, reflection questions, prayer and declaration.
- Audio streaming and direct audio-file upload to the existing `tcga-audio` bucket.
- Administrator sign-in restricted in the interface to `tcgalugbeassembly@gmail.com`.
- Create, edit, save-draft and publish devotional workflows.
- Daily local-device notification at 5:30 AM using the device's local time zone.

## 1. Configure the existing Supabase project

Project URL (already configured in the source):

`https://boxklothzymfdultubof.supabase.co`

Copy `.env.example` to `.env` in this project root and enter the **complete publishable key** supplied by the project owner:

```env
SUPABASE_URL=https://boxklothzymfdultubof.supabase.co
SUPABASE_PUBLISHABLE_KEY=PASTE_COMPLETE_SUPABASE_PUBLISHABLE_KEY_HERE
```

The key visible in the earlier chat handoff was truncated, so it is deliberately not guessed or embedded. Use only the Supabase publishable key in the mobile app. Never place a service-role/secret key in Flutter, `.env`, source control, or an APK.

## 2. Flutter build

Install the current stable Flutter SDK and Android Studio/Android SDK on a computer. From this project directory run:

```bash
flutter create . --platforms=android
flutter pub get
flutter analyze
flutter run
```

To build the Android release package:

```bash
flutter build apk --release
```

APK output:

`build/app/outputs/flutter-apk/app-release.apk`

The source package has been corrected for the previously identified timezone and audio-upload Dart type errors. The hosted GitHub Actions workflow is intended to compile the APK; it must still complete successfully and be tested on a physical Android device.

## 3. Administrator account and database security

In Supabase Dashboard → Authentication → Users, confirm that the administrator account exists:

`tcgalugbeassembly@gmail.com`

If it does not exist, create it there and set a strong password. Do not create a duplicate if it already exists. The app's email check is only a user-interface restriction. The existing Supabase RLS policies and `is_tcga_admin()` function must remain the actual security boundary for all writes and storage uploads.

## 4. Audio

The app uploads selected MP3/M4A/AAC/WAV/OGG files to the existing public `tcga-audio` bucket and stores the resulting public URL in the devotional record. Confirm that the bucket's existing policies allow the authorised administrator to upload and app users to read. No new bucket or SQL is required if the existing setup is intact.

## 5. Existing database contract

Uses the existing `devotionals` table with columns:

`id`, `devotional_date`, `title`, `theme`, `key_scripture`, `scripture_text`, `introduction`, `teaching`, `reflection_questions`, `prayer`, `declaration`, `audio_url`, `status`, `author_name`, `approved_by`, `published_at`, `created_at`, `updated_at`.

`reflection_questions` is sent as a PostgreSQL text array (one question per line in the admin editor). Also created previously: `app_profiles`, `app_settings`, RLS/admin function and `tcga-audio` storage bucket. This package does not include any database migration.

## 6. Notification note

A daily local reminder is scheduled for 5:30 AM device-local time. Android notification permission must be granted. Battery optimisation and manufacturer background restrictions may affect delivery; validate on the target Android phone. This is a local reminder, not a remote push notification.

## 7. Pre-release acceptance checklist

- [ ] Add the complete publishable key to `.env` (do not share it in public chat).
- [ ] Run `flutter pub get` and `flutter analyze`.
- [ ] Confirm administrator sign-in and rejection of non-admin accounts.
- [ ] Save a draft, edit it, then publish a test devotional.
- [ ] Confirm the public app can read only published devotionals under RLS.
- [ ] Upload and play a test audio file.
- [ ] Confirm 5:30 AM notification permission and scheduling on a physical Android device.
- [ ] Build and install the release APK; test on more than one Android screen size.

## 8. Cloud APK build (GitHub Actions)

The repository-root workflow `.github/workflows/build-android.yml` extracts the uploaded source ZIP, generates the Android platform project in the hosted build runner, installs Flutter packages, runs `flutter analyze`, builds a release APK, and publishes the APK as a downloadable workflow artifact.

1. Create a private GitHub repository and upload the contents of this project (the `tcga_flutter_app` folder contents, not the parent folder).
2. In the repository, open **Settings → Secrets and variables → Actions → New repository secret**.
3. Name the secret `SUPABASE_PUBLISHABLE_KEY` and paste the complete Supabase **publishable** key. Do not use a `service_role` or secret key.
4. Open **Actions → Build TCGA Android APK → Run workflow** (or push to `main`).
5. When the workflow succeeds, open its run and download the artifact named `TCGA-Triumphant-Living-Android-APK`. Extract it to obtain `app-release.apk`.
6. Transfer the APK to an Android phone, allow installation from the file manager/browser when prompted, and install.

A successful cloud build is not proof that Supabase policies, audio playback, sign-in, or scheduled notifications work on a physical device. Complete the pre-release acceptance checklist above before distributing it to the congregation. The APK produced by this workflow is not Play Store-signed for publication; Play Store release signing is a separate step.
