import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/devotional_service.dart';

const adminEmail = 'tcgalugbeassembly@gmail.com';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final service = DevotionalService();
  final email = TextEditingController(text: adminEmail);
  final password = TextEditingController();
  final title = TextEditingController();
  final theme = TextEditingController();
  final date = TextEditingController(text: _today());
  final scripture = TextEditingController();
  final scriptureText = TextEditingController();
  final intro = TextEditingController();
  final teaching = TextEditingController();
  final reflection = TextEditingController();
  final prayer = TextEditingController();
  final declaration = TextEditingController();
  final audio = TextEditingController();
  bool busy = false;
  String? editingId;

  static String _today() {
    final d = DateTime.now();
    return '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  bool get signedIn => Supabase.instance.client.auth.currentUser?.email?.toLowerCase() == adminEmail;

  void message(String text) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> login() async {
    setState(() => busy = true);
    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: email.text.trim(), password: password.text,
      );
      if (!signedIn) {
        await Supabase.instance.client.auth.signOut();
        message('This account is not authorised for TCGA administration.');
      }
    } on AuthException catch (e) {
      message('Sign-in failed: ${e.message}');
    } catch (e) {
      message('Sign-in failed. Please check your connection and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> chooseAudio() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['mp3', 'm4a', 'aac', 'wav', 'ogg'],
        withData: true,
      );
      if (result == null || result.files.single.bytes == null) return;
      setState(() => busy = true);
      final file = result.files.single;
      final url = await service.uploadAudio(fileName: file.name, bytes: file.bytes!);
      audio.text = url;
      message('Audio uploaded successfully.');
    } catch (e) {
      message('Audio upload failed. Confirm the tcga-audio bucket permissions.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> publish({required bool publishNow}) async {
    if (title.text.trim().isEmpty || date.text.trim().isEmpty || scripture.text.trim().isEmpty) {
      message('Please enter the date, title and key Scripture reference.');
      return;
    }
    final parsedDate = DateTime.tryParse(date.text.trim());
    if (parsedDate == null || date.text.trim().length != 10) {
      message('Enter the date in YYYY-MM-DD format.');
      return;
    }
    setState(() => busy = true);
    try {
      final now = DateTime.now().toIso8601String();
      final questions = reflection.text
          .split('\n')
          .map((q) => q.trim())
          .where((q) => q.isNotEmpty)
          .toList();
      final values = <String, dynamic>{
        'devotional_date': date.text.trim(),
        'title': title.text.trim(),
        'theme': theme.text.trim(),
        'key_scripture': scripture.text.trim(),
        'scripture_text': scriptureText.text.trim(),
        'introduction': intro.text.trim(),
        'teaching': teaching.text.trim(),
        'reflection_questions': questions,
        'prayer': prayer.text.trim(),
        'declaration': declaration.text.trim(),
        'audio_url': audio.text.trim().isEmpty ? null : audio.text.trim(),
        'status': publishNow ? 'published' : 'draft',
        'author_name': adminEmail,
        'published_at': publishNow ? now : null,
      };
      await service.save(values, id: editingId);
      message(publishNow ? 'Devotional published successfully.' : 'Draft saved successfully.');
      if (publishNow) _clearForm();
    } on PostgrestException catch (e) {
      message('Save failed: ${e.message}');
    } catch (e) {
      message('Save failed. Check your internet connection and administrator permissions.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _clearForm() {
    editingId = null;
    date.text = _today();
    for (final c in [title, theme, scripture, scriptureText, intro, teaching, reflection, prayer, declaration, audio]) {
      c.clear();
    }
    if (mounted) setState(() {});
  }

  Future<void> loadExisting(Map<String, dynamic> row) async {
    setState(() => busy = true);
    try {
      final data = await Supabase.instance.client.from('devotionals').select().eq('id', row['id']).single();
      editingId = row['id'].toString();
      date.text = data['devotional_date']?.toString() ?? _today();
      title.text = data['title']?.toString() ?? '';
      theme.text = data['theme']?.toString() ?? '';
      scripture.text = data['key_scripture']?.toString() ?? '';
      scriptureText.text = data['scripture_text']?.toString() ?? '';
      intro.text = data['introduction']?.toString() ?? '';
      teaching.text = data['teaching']?.toString() ?? '';
      final qs = data['reflection_questions'];
      reflection.text = qs is List ? qs.join('\n') : (qs?.toString() ?? '');
      prayer.text = data['prayer']?.toString() ?? '';
      declaration.text = data['declaration']?.toString() ?? '';
      audio.text = data['audio_url']?.toString() ?? '';
      if (mounted) setState(() {});
    } catch (_) {
      message('Unable to open this devotional.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    for (final c in [email, password, title, theme, date, scripture, scriptureText, intro, teaching, reflection, prayer, declaration, audio]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Administration'),
      actions: [if (signedIn) IconButton(
        tooltip: 'Sign out', icon: const Icon(Icons.logout),
        onPressed: () async { await Supabase.instance.client.auth.signOut(); if (mounted) setState(() {}); },
      )],
    ),
    body: signedIn ? _editor() : _login(),
  );

  Widget _login() => ListView(padding: const EdgeInsets.all(24), children: [
    const Text('Administrator Sign In', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('Access is restricted to the authorised TCGA administrator account.'),
    const SizedBox(height: 20),
    TextField(controller: email, readOnly: true, decoration: const InputDecoration(labelText: 'Administrator email', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
    const SizedBox(height: 16),
    FilledButton(onPressed: busy ? null : login, child: Text(busy ? 'Please wait…' : 'Sign in')),
  ]);

  Widget _editor() => ListView(padding: const EdgeInsets.all(20), children: [
    Text(editingId == null ? 'Create Devotional' : 'Edit Devotional', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    _field(date, 'Date (YYYY-MM-DD)'), _field(title, 'Devotional title'), _field(theme, 'Theme'),
    _field(scripture, 'Key Scripture reference'), _field(scriptureText, 'Scripture text', lines: 3),
    _field(intro, 'Introduction', lines: 4), _field(teaching, 'Devotional message, Kingdom insight, practical application, lessons, action point and further study', lines: 12),
    _field(reflection, 'Reflection questions (one question per line)', lines: 4),
    _field(prayer, 'Prayer', lines: 4), _field(declaration, 'Declaration', lines: 3),
    TextField(controller: audio, decoration: const InputDecoration(labelText: 'Audio URL', border: OutlineInputBorder())),
    const SizedBox(height: 8), OutlinedButton.icon(onPressed: busy ? null : chooseAudio, icon: const Icon(Icons.upload_file), label: const Text('Upload audio file')),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(child: OutlinedButton(onPressed: busy ? null : () => publish(publishNow: false), child: const Text('Save Draft'))),
      const SizedBox(width: 12),
      Expanded(child: FilledButton.icon(onPressed: busy ? null : () => publish(publishNow: true), icon: const Icon(Icons.publish), label: const Text('Publish'))),
    ]),
    if (editingId != null) TextButton(onPressed: busy ? null : _clearForm, child: const Text('Create a new devotional')),
    const Divider(height: 32),
    const Text('Existing devotionals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    FutureBuilder<List<Map<String, dynamic>>>(
      future: service.adminList(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
        if (snapshot.hasError) return const Text('Could not load existing devotionals.');
        final rows = snapshot.data ?? [];
        if (rows.isEmpty) return const Text('No devotionals have been created yet.');
        return Column(children: rows.map((row) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(row['title']?.toString() ?? 'Untitled'),
          subtitle: Text('${row['devotional_date']} • ${row['status']}'),
          trailing: const Icon(Icons.edit_outlined),
          onTap: busy ? null : () => loadExisting(row),
        )).toList());
      },
    ),
  ]);

  Widget _field(TextEditingController c, String label, {int lines = 1}) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(controller: c, maxLines: lines, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(), alignLabelWithHint: true)),
  );
}
