import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/devotional_service.dart';
import 'devotional_screen.dart';

class ArchiveScreen extends StatelessWidget {
  const ArchiveScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Devotional Archive')), body: FutureBuilder<List<Map<String, dynamic>>>(future: DevotionalService().archive(), builder: (context, s) {
    if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return const Center(child: Text('Could not load the archive.'));
    final rows = s.data ?? [];
    if (rows.isEmpty) return const Center(child: Text('No published devotionals yet.'));
    return ListView.separated(itemCount: rows.length, separatorBuilder: (_, __) => const Divider(height: 1), itemBuilder: (context, i) { final item = rows[i]; final date = DateTime.tryParse(item['devotional_date'] ?? ''); return ListTile(leading: const CircleAvatar(child: Icon(Icons.menu_book)), title: Text(item['title'] ?? ''), subtitle: Text('${date == null ? '' : DateFormat('d MMM yyyy').format(date)} • ${item['key_scripture'] ?? ''}'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DevotionalScreen(item: item)))); });
  }));
}
