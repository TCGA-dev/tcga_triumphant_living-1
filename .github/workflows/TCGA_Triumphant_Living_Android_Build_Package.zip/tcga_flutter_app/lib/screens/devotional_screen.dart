import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class DevotionalScreen extends StatefulWidget {
  final Map<String, dynamic> item;
  const DevotionalScreen({super.key, required this.item});
  @override
  State<DevotionalScreen> createState() => _DevotionalScreenState();
}
class _DevotionalScreenState extends State<DevotionalScreen> {
  final player = AudioPlayer();
  bool loadingAudio = false;
  @override
  void dispose() { player.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final d = widget.item;
    return Scaffold(appBar: AppBar(title: const Text('Daily Devotional')), body: ListView(padding: const EdgeInsets.all(20), children: [
      Text(d['theme'] ?? '', style: const TextStyle(color: Color(0xFF98712E), fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(d['title'] ?? '', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 12), Text(d['key_scripture'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
      if ((d['scripture_text'] ?? '').toString().isNotEmpty) _section('SCRIPTURE', d['scripture_text']),
      _section('INTRODUCTION', d['introduction']), _section('THE WORD', d['teaching']), _section('REFLECTION QUESTIONS', _questions(d['reflection_questions'])), _section('PRAYER', d['prayer']), _section('DECLARATION', d['declaration']),
      if ((d['audio_url'] ?? '').toString().isNotEmpty) Card(child: ListTile(leading: const Icon(Icons.headphones), title: const Text('Audio Devotional'), subtitle: const Text('Listen to today’s message'), trailing: loadingAudio ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)) : IconButton(icon: Icon(player.playing ? Icons.pause_circle : Icons.play_circle), onPressed: () async { try { if (player.playing) { await player.pause(); } else { if (player.audioSource == null) { setState(() => loadingAudio = true); await player.setUrl(d['audio_url']); setState(() => loadingAudio = false); } await player.play(); } setState(() {}); } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Unable to play this audio file.'))); } }))),
    ]));
  }
  String _questions(dynamic value) {
    if (value is List) return value.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('\n');
    return value?.toString() ?? '';
  }

  Widget _section(String title, dynamic content) { if (content == null || content.toString().trim().isEmpty) return const SizedBox.shrink(); return Padding(padding: const EdgeInsets.only(top: 22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF174A35), letterSpacing: 1)), const SizedBox(height: 8), Text(content.toString(), style: const TextStyle(fontSize: 16, height: 1.55))])); }
}
