import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/devotional_service.dart';
import 'archive_screen.dart';
import 'admin_screen.dart';
import 'devotional_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final service = DevotionalService();
  late Future<Map<String, dynamic>?> _today;
  @override
  void initState() { super.initState(); _today = service.today(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('TRIUMPHANT CHRISTIAN GLOBAL ASSEMBLY'), centerTitle: true, actions: [IconButton(tooltip: 'Administration', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())), icon: const Icon(Icons.admin_panel_settings_outlined))]),
    body: RefreshIndicator(onRefresh: () async => setState(() => _today = service.today()), child: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: const Color(0xFF174A35), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('TRIUMPHANT LIVING DAILY DEVOTIONAL', style: TextStyle(color: Colors.white70, letterSpacing: 2)), SizedBox(height: 10), Text('Daily Encounters\nwith God', style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('An official daily devotional of the Triumphant Christian Global Assembly.', style: TextStyle(color: Colors.white70))])),
      const SizedBox(height: 24), Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()), style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 12),
      FutureBuilder<Map<String, dynamic>?>(future: _today, builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
        if (snapshot.hasError) return _message('Unable to load today’s devotional. Check your internet connection and Supabase settings.');
        final item = snapshot.data;
        if (item == null) return _message('Today’s devotional has not been published yet. Please check again later.');
        return Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item['theme'] ?? 'TODAY’S DEVOTIONAL', style: const TextStyle(color: Color(0xFF98712E), fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(item['title'] ?? '', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(item['key_scripture'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 16), FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DevotionalScreen(item: item))), child: const Text('Read Today’s Devotional'))])));
      }),
      const SizedBox(height: 14), Card(child: ListTile(leading: const Icon(Icons.library_books_outlined), title: const Text('Devotional Archive'), subtitle: const Text('Revisit previous daily devotionals'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ArchiveScreen())))),
      const SizedBox(height: 14), const Center(child: Text('“Quality People • Quality Leaders”', style: TextStyle(color: Colors.black54, fontStyle: FontStyle.italic))),
    ])),
  );
  Widget _message(String text) => Card(child: Padding(padding: const EdgeInsets.all(20), child: Text(text)));
}
