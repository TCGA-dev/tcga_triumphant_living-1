import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'services/notification_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env', isOptional: true);
  final url = dotenv.env['SUPABASE_URL'] ?? '';
  final key = dotenv.env['SUPABASE_PUBLISHABLE_KEY'] ?? '';
  if (url.isEmpty || key.isEmpty || key.contains('PASTE_')) {
    runApp(const ConfigurationApp());
    return;
  }
  await Supabase.initialize(url: url, anonKey: key);
  await NotificationService.initialize();
  runApp(const TcgaApp());
}

class ConfigurationApp extends StatelessWidget {
  const ConfigurationApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text('App configuration is incomplete. Copy .env.example to .env and add the full Supabase publishable key.', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18)),
    ))),
  );
}

class TcgaApp extends StatelessWidget {
  const TcgaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'TCGA Triumphant Living',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174A35), brightness: Brightness.light), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF8F7F2)),
    home: const HomeScreen(),
  );
}
