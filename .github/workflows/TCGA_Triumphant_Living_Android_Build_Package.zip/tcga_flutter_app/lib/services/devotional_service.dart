import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

class DevotionalService {
  final SupabaseClient _db = Supabase.instance.client;

  String _localDate(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

  Future<Map<String, dynamic>?> today() async {
    final rows = await _db
        .from('devotionals')
        .select()
        .eq('devotional_date', _localDate(DateTime.now()))
        .eq('status', 'published')
        .limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }

  Future<List<Map<String, dynamic>>> archive() async {
    final rows = await _db
        .from('devotionals')
        .select()
        .eq('status', 'published')
        .order('devotional_date', ascending: false)
        .limit(120);
    return rows.map((row) => Map<String, dynamic>.from(row)).toList();
  }

  Future<List<Map<String, dynamic>>> adminList() async {
    final rows = await _db
        .from('devotionals')
        .select('id, devotional_date, title, theme, status')
        .order('devotional_date', ascending: false)
        .limit(100);
    return rows.map((row) => Map<String, dynamic>.from(row)).toList();
  }

  Future<void> save(Map<String, dynamic> values, {String? id}) async {
    if (id == null) {
      await _db.from('devotionals').insert(values);
    } else {
      await _db.from('devotionals').update(values).eq('id', id);
    }
  }

  Future<String> uploadAudio({required String fileName, required List<int> bytes}) async {
    final safeName = fileName.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final path = 'devotionals/${DateTime.now().millisecondsSinceEpoch}_$safeName';
    await _db.storage.from('tcga-audio').uploadBinary(path, Uint8List.fromList(bytes));
    return _db.storage.from('tcga-audio').getPublicUrl(path);
  }
}
